CKEDITOR.plugins.setLang('youtube', 'zh', {
    button: '嵌入 Youtube 影片',
    title: '嵌入 Youtube 影片',
    txtEmbed: '貼上嵌入碼',
    txtUrl: '貼上 Youtube 影片 URL',
    txtWidth: '寬',
    txtHeight: '高',
    txtResponsive: '使用自適應縮放模式 (忽略設定的長寬, 以寬為基準縮放)',
    chkRelated: '影片結束時顯示建議影片',
    txtStartAt: '開始時間 (ss or mm:ss or hh:mm:ss)',
    chkPrivacy: '啟用加強隱私模式',
    chkOlderCode: '使用舊的嵌入碼',
    chkAutoplay: '自動播放',
    chkControls: '显示播放器控件',
    noCode: '必須輸入嵌入碼',
    invalidEmbed: '錯誤的嵌入碼',
    invalidUrl: '錯誤的URL',
    or: '或',
    noWidth: '必須設定寬',
    invalidWidth: '寬設定錯誤',
    noHeight: '必須設定高',
    invalidHeight: '高設定錯誤',
    invalidTime: '開始時間設定錯誤'
});
