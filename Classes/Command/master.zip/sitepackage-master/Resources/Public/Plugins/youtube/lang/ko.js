CKEDITOR.plugins.setLang('youtube', 'ko', {
	button : '유투브 비디오 삽입',
	title : '유투브 비디오 삽입',
	txtEmbed : '여기 embed 코드를 붙여넣으세요',
	txtUrl : '유투브 주소(URL)를 붙여넣으세요',
	txtWidth : '너비',
	txtHeight : '높이',
	chkRelated : '비디오 마지막에 추천 영상 보이기',
	txtStartAt : '시작 시점 (ss 또는 mm:ss 또는 hh:mm:ss)',
	chkPrivacy : '개인정보 보호 모드 활성화',
	chkOlderCode : '옛날 embed 코드 사용',
	chkAutoplay: '자동 재생',
	chkControls: '플레이어 컨트롤 표시',
	noCode : 'embed 코드 또는 URL을 입력해야 합니다',
	invalidEmbed : '입력하신 embed 코드가 유효하지 않습니다',
	invalidUrl : '입력하신 주소(URL)가 유효하지 않습니다',
	or : '또는',
	noWidth : '너비를 알려주세요',
	invalidWidth : '너비가 유효하지 않습니다',
	noHeight : '높이를 알려주세요',
	invalidHeight : '높이가 유효하지 않습니다',
	invalidTime : '시작 시점이 유효하지 않습니다',
	txtResponsive : '반응형 너비 (입력한 너비와 높이를 무시하고 창 너비에 맞춤)',
	txtNoEmbed : '비디오 이미지와 링크만 달기'
});
