CKEDITOR.plugins.setLang('youtube', 'pl', {
	button : 'Załącznik wideo z YouTube',
	title : 'Załącznik wideo z YouTube',
	txtEmbed : 'Wklej kod do umieszczenia',
	txtUrl : 'Wklej adres URL do wideo z YouTube',
	txtWidth : 'Szerokość',
	txtHeight : 'Wysokość',
	chkRelated : 'Pokaż sugerowane filmy po zakończeniu odtwarzania',
	txtStartAt : 'Rozpocznij od (ss lub mm:ss lub gg:mm:ss)',
	chkPrivacy : 'Włącz rozszerzony tryb prywatności',
	chkOlderCode : 'Użyj starego kodu',
	chkAutoplay: 'Autoodtwarzanie',
	chkControls: 'Pokaż elementy sterujące odtwarzacza',
	noCode : 'Musisz wprowadzić kod lub adres URL',
	invalidEmbed : 'Wprowadzony kod nie jest poprawny',
	invalidUrl : 'Wprowadzony adres URL nie jest poprawny',
	or : 'lub',
	noWidth : 'Musisz wpisać szerokość',
	invalidWidth : 'Wprowadzona szerokość nie jest poprawna',
	noHeight : 'Musisz wprowadzić wysokość',
	invalidHeight : 'Wprowadzona wysokość nie jest poprawna',
	invalidTime : 'Musisz wprowadzić poprawny czas rozpoczęcia',
	txtResponsive : 'El. responsywny (ignoruj szerokość i wysokość, dopasuj do szerokości)'
});