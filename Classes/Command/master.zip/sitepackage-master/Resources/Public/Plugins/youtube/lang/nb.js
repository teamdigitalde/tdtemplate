﻿CKEDITOR.plugins.setLang('youtube', 'nb', {
	button : 'Bygg inn YouTube-video',
	title : 'Bygg inn YouTube-video',
	txtEmbed : 'Lim inn embed-kode her',
	txtUrl : 'Lim inn YouTube video-URL',
	txtWidth : 'Bredde',
	txtHeight : 'Høyde',
	chkRelated : 'Vis foreslåtte videoer når videoen er ferdig',
	txtStartAt : 'Start ved (ss eller mm:ss eller hh:mm:ss)',
	chkPrivacy : 'Bruk personverntilpasset modus',
	chkOlderCode : 'Bruk gammel embedkode',
	chkAutoplay: 'Spill automatisk',
	chkControls: 'Vis spillerkontrollene',
	noCode : 'Du må legge inn en embed-kode eller URL',
	invalidEmbed : 'Emded-koden du la inn ser ikke ut til å være gyldig',
	invalidUrl : 'URLen du la inn ser ikke ut til å være gyldig',
	or : 'eller',
	noWidth : 'Du må legge inn bredde',
	invalidWidth : 'Legg inn en gyldig bredde',
	noHeight : 'Du må legge inn høyde',
	invalidHeight : 'Legg inn en gyldig høyde',
	invalidTime : 'Legg inn gyldig starttid',
	txtResponsive : 'Gjør responsiv (ignorer bredde og høyde, tilpass bredde på sida)'
});
