﻿CKEDITOR.plugins.setLang('youtube', 'el', {
    button: 'Ενσωμάτωση Youtube βίντεο',
    title: 'Ενσωμάτωση Youtube βίντεο',
    txtEmbed: 'Επικόλλησε τον κώδικα ενσωμάτωσης',
    txtUrl: 'Επικόλλησε το URL του βίντεο',
    txtWidth: 'Πλάτος',
    txtHeight: 'Ύψος',
    chkRelated: 'Εμφάνιση προτεινόμενων βίντεο μόλις ολοκληρωθεί',
    txtStartAt: 'Χρόνος εκκίνησης (ss or mm:ss or hh:mm:ss)',
    chkPrivacy: 'Ενεργοποίηση λειτουργίας ενισχυμένου απορρήτου',
    chkOlderCode: 'Χρήση παλαιού κώδικα ενσωμάτωσης',
    chkAutoplay: 'Αυτόματη εκκίνηση',
    chkControls: 'Εμφάνιση στοιχείων ελέγχου προγράμματος αναπαραγωγής',
    noCode: 'Χρειάζεται κώδικας ενσωμάτωσης ή URL',
    invalidEmbed: 'Ο κώδικας ενσωμάτωσης που εισήγατε δεν μοιάζει σωστός',
    invalidUrl: 'Το URL που εισήγατε δεν μοιάζει σωστό',
    or: 'ή',
    noWidth: 'Συμπληρώστε το πλάτος',
    invalidWidth: 'Λανθασμένο πλάτος',
    noHeight: 'Συμπληρώστε το ύψος',
    invalidHeight: 'Λανθασμένο ύψος',
    invalidTime: 'Λανθασμένος χρόνος εκκίνησης'
});
