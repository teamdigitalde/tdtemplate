<?php
return array (
  'aliasToClassNameMapping' => 
  array (
  ),
  'classNameToAliasMapping' => 
  array (
  ),
);
